create view vw_clean_events
            (event_id, user_id, app_id, event_name, event_time, ingested_at, country, media_source, campaign,
             revenue_usd) as
WITH ranked_events AS (SELECT events_raw.event_id,
                              events_raw.user_id,
                              events_raw.app_id,
                              events_raw.event_name,
                              events_raw.event_time,
                              events_raw.ingested_at,
                              events_raw.country,
                              events_raw.media_source,
                              events_raw.campaign,
                              events_raw.revenue_usd,
                              row_number()
                              OVER (PARTITION BY events_raw.event_id ORDER BY events_raw.ingested_at DESC, events_raw.event_time DESC) AS rn
                       FROM events_raw
                       WHERE events_raw.is_test = false)
SELECT event_id,
       user_id,
       app_id,
       event_name,
       event_time,
       ingested_at,
       country,
       media_source,
       campaign,
       revenue_usd
FROM ranked_events
WHERE rn = 1;

alter table vw_clean_events
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on vw_clean_events to anon;

grant delete, insert, references, select, trigger, truncate, update on vw_clean_events to authenticated;

grant delete, insert, references, select, trigger, truncate, update on vw_clean_events to service_role;

