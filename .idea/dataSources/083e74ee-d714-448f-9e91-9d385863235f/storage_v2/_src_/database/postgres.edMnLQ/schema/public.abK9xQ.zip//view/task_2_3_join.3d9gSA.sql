create view task_2_3_join(event_date, app_id, media_source, campaign, revenue, cost, roas) as
WITH daily_revenue AS (SELECT date(vw_clean_events.event_time)         AS event_date,
                              vw_clean_events.app_id,
                              vw_clean_events.media_source,
                              vw_clean_events.campaign,
                              COALESCE(sum(NULLIF(
                                      NULLIF(replace(vw_clean_events.revenue_usd, ','::text, '.'::text), 'NULL'::text),
                                      ''::text)::numeric), 0::numeric) AS total_revenue
                       FROM vw_clean_events
                       GROUP BY (date(vw_clean_events.event_time)), vw_clean_events.app_id,
                                vw_clean_events.media_source, vw_clean_events.campaign),
     daily_cost AS (SELECT campaign_costs.date                                AS event_date,
                           campaign_costs.app_id,
                           campaign_costs.media_source,
                           campaign_costs.campaign,
                           COALESCE(sum(campaign_costs.cost_usd), 0::numeric) AS total_cost
                    FROM campaign_costs
                    GROUP BY campaign_costs.date, campaign_costs.app_id, campaign_costs.media_source,
                             campaign_costs.campaign)
SELECT COALESCE(r.event_date, c.event_date)                                                           AS event_date,
       COALESCE(r.app_id, c.app_id)                                                                   AS app_id,
       COALESCE(r.media_source, c.media_source)                                                       AS media_source,
       COALESCE(r.campaign, c.campaign)                                                               AS campaign,
       COALESCE(r.total_revenue, 0::numeric)                                                          AS revenue,
       COALESCE(c.total_cost, 0::numeric)                                                             AS cost,
       COALESCE(r.total_revenue, 0::numeric) / NULLIF(COALESCE(c.total_cost, 0::numeric), 0::numeric) AS roas
FROM daily_revenue r
         FULL JOIN daily_cost c
                   ON r.event_date = c.event_date AND r.app_id = c.app_id AND r.media_source = c.media_source AND
                      r.campaign = c.campaign
ORDER BY (COALESCE(r.event_date, c.event_date)), (COALESCE(r.app_id, c.app_id)),
         (COALESCE(r.media_source, c.media_source)), (COALESCE(r.campaign, c.campaign));

alter table task_2_3_join
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on task_2_3_join to anon;

grant delete, insert, references, select, trigger, truncate, update on task_2_3_join to authenticated;

grant delete, insert, references, select, trigger, truncate, update on task_2_3_join to service_role;

